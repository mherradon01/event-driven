
This directory contains files XYZ to support a Firebase Security Rules
walkthrough for Cloud Shell and the Learn Assistant.

If you need to restart the walkthrough for any reason, at the
Cloud Shell prompt, run '~/rules-tutorial/quickstart-testing/cs-walkthrough/walkthrough.sh'.
